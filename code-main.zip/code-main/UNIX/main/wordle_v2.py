import random
from time import sleep

def wordle():
    loading = "----------------------------------------------------------------------------------------------------"
    x = 0
    for i in range(len(loading) + 1):
        print("\r |" + loading + "|", str(x) + "%", flush=True, end="")
        loading = loading.replace("-", "#", 1)
        sleep(0.1)
        x = x + 1
    print("")

    words = []
    guessed = False
    count = 6
    dash_list = []
    letter_list = []
    yellow_list = []
    green_list = []
    count_use = {}
    backup_list = []
    invalid_words = []
    answers = []

    class fg:
        reset = '\033[0m'
        black = '\033[30m'
        red = '\033[31m'
        green = '\033[32m'
        orange = '\033[33m'
        blue = '\033[34m'
        purple = '\033[35m'
        cyan = '\033[36m'
        lightgrey = '\033[37m'
        darkgrey = '\033[90m'
        lightred = '\033[91m'
        lightgreen = '\033[92m'
        yellow = '\033[93m'
        lightblue = '\033[94m'
        pink = '\033[95m'
        lightcyan = '\033[96m'

    '''
    print(fg.reset) will reset text color
    print(fg.red, "text goes here") will turn text red. After doing so
    text will stay red until reset
    '''

    with open('UNIX/main/valid-wordle-words.txt', 'r') as file:
        for i in file:
            words.append(i[:-1])

    with open('UNIX/main/wordle_answers.txt', 'r') as file:
        for i in file:
            answers.append(i[:-1])

    secret_word = random.choice(answers)
    dashes = ""
    for i in range(len(secret_word)):
        if secret_word[i] == " ":
            dashes = dashes + " "
        else:
            dashes = dashes + "-"
    dashes = list(dashes)

    while not guessed:
        if not count == 6 and count > 0:
            print("List of letters you've tried:", str(letter_list))
            print("Wrong letters:", invalid_words)
        count_use = {}
        for i in range(len(secret_word)):
            if secret_word[i] not in count_use:
                count_use[secret_word[i]] = 1
            else:
                count_use[secret_word[i]] = count_use.get(secret_word[i]) + 1
        print(fg.lightcyan)
        if count <= 0:
            break
        guess = input("Enter a five letter word: ")
        if len(guess) > len(secret_word) or len(guess) < len(secret_word):
            print("Your guess must be five letters exactly!")
            continue
        if guess not in words:
            print("Not a real word!")
            continue
        for i in range(len(guess)):
            if guess[i] not in letter_list:
                letter_list.append(guess[i])
        for i in range(len(secret_word)):
            if guess[i] in secret_word[i]:
                green_list.append(guess[i])
                backup_list.append(guess[i])
                dashes[i] = guess[i]
            elif guess[i] in secret_word:
                yellow_list.append(guess[i])
                dashes[i] = guess[i]
            else:
                dashes[i] = guess[i]
                if not guess[i] in invalid_words:
                    invalid_words.append(guess[i])
        dash_list.append(guess)
        letter_list.sort()
        invalid_words.sort()

        for i in range(len(secret_word)):
            x = 0
            if guess[i] in secret_word[i] and guess[i] not in green_list:
                green_list.append(guess[i])
            elif guess[i] in secret_word and guess[i] not in yellow_list:
                if not guess[i] in backup_list or not count_use.get(guess[i]) <= 1:
                    yellow_list.append(guess[i])
            
            if not count_use.get(guess[i]) is None and count_use.get(guess[i]) > 0:
                if dashes[i] in green_list:
                    print(fg.green, dashes[i], flush=True, end = "")
                    sleep(0.33)
                    count_use[guess[i]] = count_use.get(guess[i]) - 1
                elif not count_use.get(guess[i]) < 1:
                    if dashes[i] in yellow_list:
                        print(fg.yellow, dashes[i], flush=True, end = "")
                        sleep(0.33)
                        count_use[guess[i]] = count_use.get(guess[i]) - 1
                    else:
                        print(fg.reset, dashes[i], flush=True, end = "")
                        sleep(0.33)

                else:
                    print(fg.reset, dashes[i], flush=True, end = "")
                    sleep(0.33)
            else:
                print(fg.reset, dashes[i], flush=True, end = "")
                sleep(0.33)
            
            yellow_list = []
            green_list = []

        print(fg.lightcyan)
        backup_list = []

        if "".join(dashes) == secret_word:
            guessed = True
        count = count - 1
        if count > 0:
            print("You have", str(count), "guesses left")

    if guessed == True:
        print(fg.green)
        print("You won!")
        print(fg.lightcyan + "Your guesses:")
        for i in range(len(dash_list)):
            print(dash_list[i])
        
    else:
        print(fg.red)
        print("You lost, the word was:", secret_word)
        print(fg.lightcyan + "Your guesses:")
        for i in range(len(dash_list)):
            print(dash_list[i])
        print(fg.reset)