import os
from caesar_cypher import *
from minesweeper import *
from hangman import *
from wordle_v2 import *


def bootup():
    file = open("UNIX/main/bootup.txt")
    lines = file.readlines()
    for i in range(len(lines)):
        print(lines[i])
        sleep(round(random.random(), 1))


os.system('clear')
bootup()
print("|---------------------------------------------------------------------------------------Welcome to "
      "PyOs-----------------------------------------------------------------------------------------|")


def add_spaces(command):
    command = ' '.join(command)
    command = command.split('"')
    for i in range(len(command)):
        try:
            command.remove("")
            command.remove(" ")
        except ValueError:
            break
    command[0] = command[0].split()
    command.append(command[0][0])
    command.append(command[0][1])
    command = command[1:100]
    return command


active_directory = "main"


def cat(file, active_directory):
    try:
        reading = open("UNIX/" + active_directory + "/" + file)
        return reading.read()
    except FileNotFoundError:
        return "File doesn't exist!"


def cd(directory):
    active_directory = directory
    return (active_directory)


def help(page):
    help1 = [
        "cat [file to read] | Use: reads a file \n",
        "help [page number] | Use: lists all commands \n",
        "cd [directory] | Use: changes directory \n",
        "ls [directory] | Use: lists a directory's contents \n",
        "rm [file name] | Use: deletes a file \n"
        "replace [file name] [text to be replaced] [replacement text] | Use: replaces text in a file \n"
        "mkdir [directory name] | Use: creates a directory in your current directory \n"
    ]
    help2 = [
        "ps | Use: lists active processes \n",
        "kill [PID] | Use: stops a program \n",
        "touch [file name] | Use: creates a file in your current directory \n",
        "pwd | Use: lists your current directory \n"
        "write [file name] [\"text to write in\"] | Use: overwrites a file \n",
        "append [file name] [\"text to write in\"] | Use: adds text to the end of a file \n"
        "reboot | Use: restarts computer \n"
    ]
    help3 = [
        "Caesar [encrypt/decrypt] [word] [key] | Use: encrypts or decrypts something using the Caeser Cypher. \n"
        "Minesweeper | Use: play a game of minesweeper \n"
        "Hangman | Use: play a game of hangman \n"
        "Wordle | Use: play a game of wordle \n"
    ]
    if page == 1:
        return (''.join(help1))
    elif page == 2:
        return (''.join(help2))
    elif page == 3:
        return (''.join(help3))


def mkdir(directory, active):
    parent_dir = "UNIX/" + active
    path = os.path.join(parent_dir, directory)
    os.mkdir(path)


def cls():
    os.system('clear')


def CaesarCypher(type, word, number):
    number = int(number)
    if type.lower() == "encrypt":
        return (encypher(word, number))
    elif type.lower() == "decrypt":
        return (decypher(word, number))
    else:
        return ("Invalid option")


def write(file, active_directory, text):
    with open("UNIX/" + active_directory + "/" + file, "w") as file:
        file.write(text)


def append(file, active_directory, text):
    with open("UNIX/" + active_directory + "/" + file, "a") as file:
        file.write(text)


def replace(file, active_directory, search_text, replacement):
    with open('UNIX/' + active_directory + '/' + file, 'r') as f:
        data = f.read()
        data = data.replace(search_text, replacement)
    with open('UNIX/' + active_directory + '/' + file, 'w') as f:
        f.write(data)


def pwd():
    return ("UNIX/" + active_directory)


def touch(file, active_directory):
    print(active_directory)
    f = open("UNIX/" + active_directory + "/" + file, "x")


def ls(directory):
    if directory == "UNIX":
        return (os.listdir("UNIX"))
    else:
        try:
            return (os.listdir("UNIX/" + directory))
        except FileNotFoundError:
            return ("Directory doesn't exist!")


def ps():
    return ("python: 42")


def kill(PID):
    if PID == "42":
        return (True)
    else:
        return (False)


def rm(file, active_directory):
    try:
        os.remove("UNIX/" + active_directory + "/" + file)
    except FileNotFoundError:
        print("File not found!")


command = "Na"
while True:
    command = input("").split(" ")

    if str(command[0]) == "help":
        for i in range(1, 4):
            if int(command[1]) == i:
                print(help(i))
                y = True

    if str(command[0]) == "cd":
        try:
            active_directory = cd(command[1])
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "cat":
        try:
            print(cat(command[1], active_directory))

        except IndexError:
            print("Index Error!")

    if str(command[0]) == "ls":
        try:
            print(ls(command[1]))
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "ps":
        print(ps())

    if str(command[0]) == "kill":
        try:
            if kill(command[1]):
                break
            else:
                print("PID not found!")
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "rm" and command[1] != "terminal.py":
        try:
            rm(command[1], active_directory)
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "touch":
        try:
            touch(command[1], active_directory)
        except IndexError:
            print("Index Error!")
    if str(command[0]) == "pwd":
        print(pwd())
    if str(command[0]) == "write":
        command = add_spaces(command)
        try:
            write(command[2], active_directory, command[0])
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "append":
        command = add_spaces(command)
        try:
            append(command[2], active_directory, command[0])
        except IndexError:
            print("Index Error!")

    if str(command[0]) == "replace":
        command = add_spaces(command)
        try:
            replace(command[3], active_directory, command[0], command[1])
        except IndexError:
            print("Index Error!")
    if str(command[0]) == "Caesar":
        try:
            print("Output: \"" + CaesarCypher(command[1], command[2], command[3]) + "\"")
        except IndexError:
            print("Index Error!")
    if str(command[0]) == "mkdir":
        try:
            mkdir(command[1], active_directory)
        except IndexError:
            print("Index Error!")
    if str(command[0]) == "cls":
        cls()
        print(
            "|---------------------------------------------------------------------------------------Welcome to PyOs-----------------------------------------------------------------------------------------|")
    if str(command[0]).lower() == "minesweeper":
        minesweeper()
    if str(command[0]).lower() == "hangman":
        hangman()
    if str(command[0]).lower() == "wordle":
        wordle()
    if str(command[0]) == "reboot":
        for i in range(1, 6):
            print(str(i) + "...", end="", flush=True)
            sleep(0.25)
        print("")
        os.system('clear')
        bootup()
