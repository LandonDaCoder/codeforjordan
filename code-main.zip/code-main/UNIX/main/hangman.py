import random
from time import sleep
def hangman():
    loading = "----------------------------------------------------------------------------------------------------"
    x = 0
    for i in range(len(loading) + 1):
        print("\r |" + loading + "|", str(x) + "%", flush=True, end="")
        loading = loading.replace("-", "#", 1)
        sleep(0.05)
        x = x + 1
    print("")
    words = []
    with open('UNIX/main/hangman_word_list.txt', 'r') as file:
        for i in file:
            words.append(i[:-1])
    secret_word = random.choice(words)
    dashes = ""
    for i in range(len(secret_word)):
        if secret_word[i] == " ":
            dashes = dashes + " "
        else:
            dashes = dashes + "-"
    dashes = list(dashes)
    guesses_left = 0
    prev_guess = []

    def check_guess(prev_guess, guess):
        for i in range(len(prev_guess)):
            if guess in prev_guess:
                return(True)
        
    def update_dashes(guess, dashes, secret_word, c):
        x = 0
        result = ""
        for i in range(len(secret_word)):
            if secret_word[i] == guess:
                dashes[i] = guess
            else:
                x = x + 1
        if c != 1:
            print(''.join(dashes))
        return(x)
    def win_check(dashes, secret_word):
        x = 0
        for i in range(len(dashes)):
            if dashes[i] == "-":
                x = 1
        if x == 0:
            return(True)
    print("--------------------------------Hangman-------------------------------")
    print(" ")
    print("The word in question: " + ("-"*len(dashes)))
    print(" ")
    while win_check(dashes, secret_word) != True:
        if win_check(dashes, secret_word):
            break
        c = 0
        if guesses_left >= 10:
            break
        guess = input("Enter a lowercase letter: ")
        if not guess.islower():
            print("Your guess must be a lowercase letter!")
            continue
        if len(guess) > 1:
            print("Your guess must have exactly one character!")
            continue
        if check_guess(prev_guess, guess):
            print("You've tried these letters: " + ", ".join(prev_guess))
            continue
        prev_guess.append(guess)
        update_dashes(guess, dashes, secret_word, c)
        c = 1
        if update_dashes(guess, dashes, secret_word, c) >= len(secret_word):
            guesses_left = guesses_left + 1
            print("Incorrect guess, you have " + str(10 - guesses_left) + " incorrect guesses left")
    if win_check(dashes, secret_word):
        print("You win!")
        print("--------------------------Good Job-------------------------")
    else:
        print("You lose! The word was: " + secret_word)
        print("--------------------------Bad Job--------------------------")