import random
import os
from time import sleep
def minesweeper():
    loading = "----------------------------------------------------------------------------------------------------"
    x = 0
    for i in range(len(loading) + 1):
        print("\r |" + loading + "|", str(x) + "%", flush=True, end="")
        loading = loading.replace("-", "#", 1)
        sleep(0.1)
        x = x + 1
    print("")
    backup_board = [
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "]
            ]
    for i in range(40):
        backup_board[random.randrange(0, 17)][random.randrange(0, 17)] = "m"
    # Get row or column from user
    def get_valid_index(prompt):
        while True:
            try:
                index = int(input(prompt))
                if index >= 1 and index <= 18:
                    return index
                print("Must be 1 - 18 inclusive!")
            except ValueError:
                print("Must be an integer!")

    # game_is_over
    # -----
    # Return True if the game is over and False
    # otherwise. Print a message indicating who
    # won or whether there was a tie.
        
    # print_board
    # -----
    # Print the board.
    def print_board(board):
        for i in range(18):
            if i < 9:
                print(str(i + 1) + " ", board[i])
            elif i >= 10:
                print(str(i + 1),board[i])
    def print_backup(board):
        for i in range(18):
            print(board[i])
    board = [
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "],
        [" ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " ", " "]
            ]
    '''
        col1 col2 col3
    row 1["ul", "u", "ur"]
    row 2["l", "c", "r"]
    row 3["dl", "d", "dr"]
    row - 1 col - 1 = c
    row - 2 col - 1 = u
    row - 1 col - 2 = l
    row - 1 col + 0 = r
    row + 0 col - 1 = d
    row + 0 col - 2 = dl
    row + 0 col + 0 = dr
    row - 2 col - 2 = ul
    row - 2 col + 0 = ur
    '''
    def check_board(row, col, backup_board):
        x = 0
        if backup_board[row - 2][col - 1] == "m":
            x = x + 1
        if backup_board[row - 1][col - 2] == "m":
            x = x + 1
        if backup_board[row - 2][col - 2] == "m":
            x = x + 1
        if backup_board[row][col - 1] == "m":
            x = x + 1
        if backup_board[row][col - 2] == "m":
            x = x + 1
        if backup_board[row - 1][col] == "m":
            x = x + 1
        if backup_board[row - 2][col] == "m":
            x = x + 1
        if backup_board[row][col] == "m":
            x = x + 1
        return(str(x))
    column_num = "     1    2    3    4    5    6    7    8    9   10   11   12   13   14   15   16   17   18"
    count = 0
    first = True
    while True:
        if count >= 284:
            game_win = True
        print(column_num)
        print_board(board)
        row = get_valid_index("Row: ")
        col = get_valid_index("Col: ")
        print("")
        if backup_board[row - 1][col - 1] == "m":
            os.system('clear')
            print_backup(backup_board)
            game_win = False
            break
        elif board[row - 1][col - 1] == " ":
            board[row - 1][col - 1] = check_board(row, col, backup_board)
        else:
            print("Pick an empty space!")
            continue
        if first:
            for i in range(40):
                row = random.randrange(0, 17)
                col = random.randrange(0, 17)
                board[row][col] = check_board(row, col, backup_board)
            first = False
        count = count + 1
    if game_win:
        print("You win!")
    else:
        print("You lose!")