class fg:
    green = '\033[32m'
    gray = '\033[90m'
    yellow = '\033[93m'
    reset = '\033[0m'
    red = '\033[31m'
Cash = -6

#print("Money: ", Fore.GREEN + str(Cash) if Cash >= 0 else Fore.RED + str(Cash)) example if else statement inside a print()

t = True
f = False

print("Money: ", fg.green + str(Cash) if t == True else fg.red + str(Cash))
