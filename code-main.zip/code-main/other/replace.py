def replace(file, search_text, replacement):
    with open(file, 'r') as f: 
        data = f.read()
        data = data.replace(search_text, replacement) 
    with open(file, 'w') as f: 
        f.write(data)


while True:
    command = input("").split()
    if str(command[0]) == "replace":
        command = ' '.join(command)
        command  = command.split('"')
        print(command)
        for i in range(len(command)):
            try:
                command.remove("")
                command.remove(" ")
            except ValueError:
                break
        command[0] = command[0].split()
        command.append(command[0][0])
        command.append(command[0][1])
        try:
            replace(command[4], command[1], command[2])
        except IndexError:
            print("Index Error!")