def uncensored(word, vowel):
    for i in range(len(vowel)):
        word = word.replace("*", vowel[i], 1)
    return word


print(uncensored("Wh*r* d*d th* v*w*ls g*?", "eeieoeo"))