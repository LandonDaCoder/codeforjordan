import random
words = []

guessed = False
count = 6
dash_list = []
letter_list = []
yellow_list = []
green_list = []

class fg:
    reset = '\033[0m'
    black = '\033[30m'
    red = '\033[31m'
    green = '\033[32m'
    orange = '\033[33m'
    blue = '\033[34m'
    purple = '\033[35m'
    cyan = '\033[36m'
    lightgrey = '\033[37m'
    darkgrey = '\033[90m'
    lightred = '\033[91m'
    lightgreen = '\033[92m'
    yellow = '\033[93m'
    lightblue = '\033[94m'
    pink = '\033[95m'
    lightcyan = '\033[96m'

'''
print(fg.reset) will reset text color
print(fg.red, "text goes here") will turn text red. After doing so
text will stay red until reset
'''


with open('words.txt', 'r') as file:
    for i in file:
        words.append(i[:-1])

secret_word = random.choice(words)
dashes = ""
for i in range(len(secret_word)):
    if secret_word[i] == " ":
        dashes = dashes + " "
    else:
        dashes = dashes + "-"
dashes = list(dashes)

while not guessed:
    print(fg.lightcyan)
    if count <= 0:
        break
    guess = input("Enter a fiver letter word: ")
    if len(guess) > 5 or len(guess) < 5:
        print("Your guess must be five letters exactly!")
        continue
    if guess not in words:
        print("Not a real word!")
        continue
    for i in range(len(guess)):
        if guess[i] not in letter_list:
            letter_list.append(guess[i])
    for i in range(len(secret_word)):
        if guess[i] in secret_word[i]:
            green_list.append(guess[i])
            dashes[i] = guess[i]
        elif guess[i] in secret_word:
            yellow_list.append(guess[i])
            dashes[i] = guess[i]
        else:
            dashes[i] = guess[i]
    dash_list.append(guess)
    print("".join(dashes))
    letter_list.sort()
    print("List of letters you've tried:", str(letter_list))

    for i in range(5):
        if guess[i] in secret_word[i]:
            green_list.append(guess[i])
        elif guess[i] in secret_word:
            yellow_list.append(guess[i])
        if dashes[i] in green_list:
            print(fg.green, dashes[i], end = "")
        elif dashes[i] in yellow_list:
            print(fg.yellow, dashes[i], end = "")
        else:
            print(fg.reset, dashes[i], end = "")
        yellow_list = []
        green_list = []


    print(fg.lightcyan)

    if "".join(dashes) == secret_word:
        guessed = True
    count = count - 1
    print("You have", str(count), "guesses left")

if guessed == True:
    print("You won!")
    print("Your guesses:")
    for i in range(len(dash_list)):
        print(dash_list[i])
else:
    print("You lost, the word was:", secret_word)
    print("Your guesses:")
    for i in range(len(dash_list)):
        print(dash_list[i])