'''
fraction1 = input("Enter your first fraction (enter your variable as a \"1\"): ")
fraction2 = input("Enter your second fraction (don't enter a variable): ")
#Index 0 should be the top of the fraction and index 1 should be the bottom. 
fraction1 = fraction1.split(" ")
fraction2 = fraction2.split(" ")

num1 = int(fraction1[0]) * int(fraction2[1])
num2 = int(fraction2[0]) * int(fraction1[1])
print(num2/num1)
'''

'''
pair = input("Enter your two numbers: ")
extra = input("Enter your two numbers to add/subtract by: ")
pair = pair.split(" ")
num2 = int(pair[0]) * int(pair[1])
extra = extra.split(" ")
num3 = int(extra[0]) * int(extra[1])
y = int(input("Enter your variable: "))

choice = input("Are you adding or subtracting? (Enter \"-\" or \"+\"): ")

if choice == "-":
    print(("Your variable =",num2 - num3)/y)
elif choice == "+":
    print("Your variable =",(num2 - num3)/y)
'''
operation = []

num1 = input("Enter your first numerator (enter your variable as a \"1\"): ").split(" ")
den1 = input("Enter your first denominator (don't enter a variable): ").split(" ")

num2 = input("Enter your second numerator (enter your variable as a \"1\"): ").split(" ")
den2 = input("Enter your second denominator (don't enter a variable): ").split(" ")

operation.append(num1)
operation.append(den1)
operation.append(num2)
operation.append(den2)
print(operation)