#Also would be nice if I could calculate area and perimeter.
import math
coord_list = []
option = "Na"
while option:
    option = input("Enter 'k', 'origin' or 'coords' (use 'False' to stop the program): ")
    if option == "coords":
        coord_list = []
        c = int(input("Enter # of points: "))
        for i in range(c):
            coord = input("Enter point " + str(i + 1) + ": ")
            coord = tuple(int(x) for x in coord.split(","))
            coord_list.append(coord)
        print(coord_list)
        k = float(input("Enter k (dilation factor): "))
        for i in range(c):
            #This works by drawing the x and y from each pair of coordinates from the list, then multiplying them by "k"
            print("(" + str(float(coord_list[i][0]*k)) + ", " + str(float(coord_list[i][1]*k)) + ")")
    elif option == "k":
        coord_list = []
        choice = input("Side length (\"side\") or side length with coordinates (\"side point\") or coordinates (\"coord\"): ")
        if choice == "coord":
            print("Enter pre-image then image coordinates for one point:")
            #K (the dilation factor) is equal to the image over the pre-image or "image/pre-image"
            for i in range(2):
                if i == 0:
                    coord = input("Enter pre-image: ")
                    coord = tuple(int(x) for x in coord.split(","))
                else:
                    coord = input("Enter image: ")
                    coord = tuple(int(x) for x in coord.split(","))
                coord_list.append(coord)
            print(coord_list)
            #This code uses the k formula image/pre-image to determine k by pulling coordinates from coord_list
            try:
                if float(coord_list[1][1]/coord_list[0][1]) != float(coord_list[1][0]/coord_list[0][0]):
                    print("Both x and y should have the same dilation factor, are these the right coordinates?")
                elif float(coord_list[1][1]/coord_list[0][1]) == float(coord_list[1][0]/coord_list[0][0]):
                    try:
                        print("K = " + str(float(coord_list[1][0]/coord_list[0][0])))
                    except ZeroDivisionError:
                        print("...")
                    try:
                        print("K = " + str(float(coord_list[1][1]/coord_list[0][1])))
                    except ZeroDivisionError:
                        print("Divsion by x and y results in 0. Try a different point")
            except ZeroDivisionError:
                try:
                    print("K = " + str(float(coord_list[1][0]/coord_list[0][0])))
                except ZeroDivisionError:
                    try:
                        print("K = " + str(float(coord_list[1][1]/coord_list[0][1])))
                    except ZeroDivisionError:
                        print("K = 0")
                
        elif choice == "side":
            print("Enter pre-dilation side length, then enter post-dilation side length")
            pre_dilation = float(input("Enter pre-dilation side length: "))
            post_dilation = float(input("Enter post-dilation side length: "))
            print("K = " + str(post_dilation/pre_dilation) + " or " + str(post_dilation) + "/" + str(pre_dilation))
        elif choice == "side point":
            coord_list = []
            coord_list = list(coord_list)
            for i in range(4):
                coord = input("Enter point " + str(i) + ": ")
                coord = tuple(int(x) for x in coord.split(","))
                coord_list.append(coord)
            distance1 = math.sqrt((coord_list[0][0] - coord_list[1][0])**2 + (coord_list[0][1] - coord_list[1][1])**2)
            distance2 = math.sqrt((coord_list[2][0] - coord_list[3][0])**2 + (coord_list[2][1] - coord_list[3][1])**2)
            print("The distance of pre-dilation line is: " + str(distance1))
            print("The distance of post-dilation line is: " + str(distance2))
            print("K: " + str(distance2/distance1) + " or " + str(distance2) + "/" + str(distance1))
        else:
            print("Invalid option")
    elif option == "origin":
        point = input("Enter the coordinates of the point acting as origin (it should be entered as \"x, y\"): ")
        point = tuple(int(x) for x in point.split(","))
        print(point)
        coord_list = []
        c = int(input("Enter # of points: "))
        for i in range(c):
            coord = input("Enter point " + str(i + 1) + ": ")
            coord = tuple(int(x) for x in coord.split(","))
            #This bit is important because it finds the distance between the point and x, y allowing it to become the new origin
            coord = list(coord)
            coord[0] = coord[0] - point[0]
            coord[1] = coord[1] - point[1]
            coord_list.append(coord)
        print(coord_list)
        k = float(input("Enter k (dilation factor): "))
        for i in range(c):
            #This works by drawing the x and y from each pair of coordinates from the list, then multiplying them by "k"
            print("From the point (the acting-origin), point " + str(i + 1) + " is: (" + str(float(coord_list[i][0]*k)) + ", " + str(float(coord_list[i][1]*k)) + ")")
        for i in range(c):
            #This works by adding the point (since it was subtracted earlier) to get coordinates assuming an origin of 0, 0 instead of the point
            print("From the origin, point " + str(i + 1) + " is: (" + str(float(coord_list[i][0]*k + point[0])) + ", " + str(float(coord_list[i][1]*k + point[1])) + ")")
    elif option == "False":
        break
    else:
        print("Invalid option")