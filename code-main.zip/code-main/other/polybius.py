#https://edabit.com/challenge/2C3gtb4treAFyWJMg
from textwrap import wrap



print("    1	2	3	4	5")
print("1	A	B	C	D	E")
print("2	F	G	H	I/J	K")
print("3	L	M	N	O	P")
print("4	Q	R	S	T	U")
print("5	V	W	X	Y	Z")

def polybius(string):
    x = 0
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    no_j = "abcdefghiklmnopqrstuvwxyz"
    poly = "11121314152122232425313233343541424344455152535455"
    poly = wrap(poly, 2)

    for i in range(len(string)):
        if not string[i] in alphabet:
            x = x + 1

    if x >= len(string):
        string: list[str] = string.split()
        for i in range(len(string)):
            string[i] = wrap(string[i], 2)
        for c in range(len(string)):
            for i in range(len(string[c][:])):
                letter = poly.index(string[c][i])
                string[c][i] = no_j[letter]
        string = list(string)
        return(string)
        

    elif x < len(string):
        string = list(string)
        for i in range(len(string)):
            if string[i].lower() == "j":
                string[i] = "24"
            elif string[i].lower() in no_j:
                number = no_j.find(string[i].lower())
                string[i] = poly[number]

        return(''.join(string))
while True:
    print(polybius(input("Enter some text: ")))

