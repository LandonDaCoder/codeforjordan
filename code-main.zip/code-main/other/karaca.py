def karaca(word):
    word = list(word)
    backup_word = list(''.join(word))
    for i in range(len(word)):
        word[i] = backup_word[-i - 1]
    for i in range(len(word)):
        if word[i] == "a":
            word[i] = "0"
        if word[i] == "e":
            word[i] = "1"
        if word[i] == "i":
            word[i] = "2"
        if word[i] == "o":
            word[i] = "2"
        if word[i] == "u":
            word[i] = "3"
    word = ''.join(word)
    return word


print(karaca("omega"))
