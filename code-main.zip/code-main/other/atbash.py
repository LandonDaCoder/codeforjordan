alphabet = list("abcdefghijklmnopqrstuvwxyz")
upper_alphabet = list("ABCDEFGHIJKLMNOPQRSTUVWXYZ")


word = list("atbash")
for i in range(len(word)):
    if word[i] in alphabet:
        number = ''.join(alphabet).find(word[i])
        word[i] = alphabet[-number - 1]
    elif word[i] in upper_alphabet:
        number = ''.join(upper_alphabet).find(word[i])
        word[i] = upper_alphabet[-number - 1]
    
print(''.join(word))