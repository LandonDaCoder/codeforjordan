x = 0


def snake_fill(board):
    number = 1
    x = 0
    while True:
        if number > board:
            break
        number = number * 2
        x = x + 1
    print(x - 1)


snake_fill(25)
