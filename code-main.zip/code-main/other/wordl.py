import random
words = []

guessed = False
count = 6
dash_list = []
letter_list = []
yellow_list = []
green_list = []

class fg:
    green = '\033[32m'
    gray = '\033[90m'
    yellow = '\033[93m'
    reset = '\033[0m'
    red = '\033[31m'

'''
print(fg.reset) will reset text color
print(fg.red, "text goes here") will turn text red. After doing so text will stay red until reset
'''


with open('words.txt', 'r') as file:
    for i in file:
        words.append(i[:-1])

secret_word = random.choice(words)
dashes = ""
for i in range(len(secret_word)):
    if secret_word[i] == " ":
        dashes = dashes + " "
    else:
        dashes = dashes + "-"
dashes = list(dashes)

while not guessed:
    if count <= 0:
        break
    guess = input("Enter a fiver letter word: ")
    if len(guess) > 5 or len(guess) < 5:
        print("Your guess must be five letters exactly!")
        continue
    if guess not in words:
        print("Not a real word!")
        continue
    for i in range(len(guess)):
        if guess[i] not in letter_list:
            letter_list.append(guess[i])
    for i in range(len(secret_word)):
        if guess[i] in secret_word[i]:
            green_list.append(guess[i])
            dashes[i] = guess[i]
        elif guess[i] in secret_word:
            yellow_list.append(guess[i])
            dashes[i] = guess[i]
    dash_list.append(guess)
    print("".join(dashes))
    letter_list.sort()
    print("List of letters you've tried:", str(letter_list))
    '''
    This code doesn't work because with having two of one letter (such as tools which has 2 "o"'s) the program will mark the letter "o" as both
    being in the right place and being in the wrong place, because there's two of them. The program has no way of differentiating between the "o"s.
    '''
    for i in range(5):
        if dashes[i] in green_list:
            print(fg.green, dashes[i])
        if dashes[i] in yellow_list:
            print(fg.yellow, dashes[i])
        else:
            print(fg.reset, dashes[i])

    print(fg.reset)
    yellow_list = []

    if "".join(dashes) == secret_word:
        guessed = True
    count = count - 1
    print("You have", str(count), "guesses left")

if guessed == True:
    print("You won!")
    print("Your guesses:")
    for i in range(len(dash_list)):
        print(dash_list[i])
else:
    print("You lost, the word was:", secret_word)
    print("Your guesses:")
    for i in range(len(dash_list)):
        print(dash_list[i])