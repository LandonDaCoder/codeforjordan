from time import sleep
#print("\r |" + loading + "|", str(x) + "%", flush=True, end="")
print("\r o", end="")
print("\r r", end="")