def encrypt(entered):
    encrypted = []
    for i in entered:
        if i == "a":
            encrypted.append("01100001")
        elif i == "b":
            encrypted.append("01100010")
        elif i == "c":
            encrypted.append("01100011")
        elif i == "d":
            encrypted.append("01100100")
        elif i == "e":
            encrypted.append("01100101")
        elif i == "f":
            encrypted.append("01100110")
        elif i == "g":
            encrypted.append("01100111")
        elif i == "h":
            encrypted.append("01101000")
        elif i == "i":
            encrypted.append("01101001")
        elif i == "j":
            encrypted.append("01101010")
        elif i == "k":
            encrypted.append("01101011")
        elif i == "l":
            encrypted.append("01101100")
        elif i == "m":
            encrypted.append("01101101")
        elif i == "n":
            encrypted.append("01101110")
        elif i == "o":
            encrypted.append("01101111")
        elif i == "p":
            encrypted.append("01110000")
        elif i == "q":
            encrypted.append("01110001")
        elif i == "r":
            encrypted.append("01110010")
        elif i == "s":
            encrypted.append("01110011")
        elif i == "t":
            encrypted.append("01110100")
        elif i == "u":
            encrypted.append("01110101")
        elif i == "v":
            encrypted.append("01110110")
        elif i == "w":
            encrypted.append("01110111")
        elif i == "x":
            encrypted.append("01111000")
        elif i == "y":
            encrypted.append("01111001")
        elif i == "z":
            encrypted.append("01111010")
    encrypted = ''.join(encrypted)
    return(encrypted)