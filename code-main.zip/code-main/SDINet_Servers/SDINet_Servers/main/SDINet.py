from test_encrypt import *


class color:
    black = '\033[30m'
    red = '\033[31m'
    green = '\033[32m'
    orange = '\033[33m'
    blue = '\033[34m'
    purple = '\033[35m'
    cyan = '\033[36m'
    lightgrey = '\033[37m'
    darkgrey = '\033[90m'
    lightred = '\033[91m'
    lightgreen = '\033[92m'
    yellow = '\033[93m'
    lightblue = '\033[94m'
    pink = '\033[95m'
    lightcyan = '\033[96m'
    reset = '\033[0m'

import os
with open('SDINet_Servers/main/encrypted_passes.txt', 'r') as f: 
    lines = f.readlines()
    data = {} 
    for line in lines: 
        key, value = line.strip().split(',') 
        data[key] = value
login = True
count = 3
direct = True


while login:
    name = input("Enter username: ")
    password = encrypt(input("Enter password: "))
    if name in data and password == data.get(name):
        print("Welcome back,", name)
        login = False
    elif name in data and password != data.get(name):
        print("Incorrect password!")
    else:
        print("User not registered!")
    count = count - 1
    if count <= 0:
        print("Repeated password failures, locking system...")
        exit()

if name == "admin" and password == data.get("admin"):
    admin = True
else:
    admin = False

while True:
    choice = input("Would you like to browse files or exit? ('file' or 'exit') ")
    if choice == "file":
        "Opening files..."
        break
    elif choice == "exit":
        print("Exiting...")
        exit()
    else:
        print("Invalid choice")
        continue

while True:
    print(os.listdir("SDINet_Servers"))
    file_directory = input("What directory would you like to look at? ")
    if file_directory == "restricted" and not admin:
        print(color.red + "Warning: You do not have sufficient permissions to access this directory.")
        print(color.reset)
        continue
    print(os.listdir("SDINet_Servers/" + file_directory))
    file_name = input("What file would you like to read? (Remember to add the .txt or .py at the end of the file!): ")
    print(color.green)
    f = open("SDINet_Servers/" + file_directory + "/" + file_name, "r")
    print(f.read()) 
    print(color.reset)