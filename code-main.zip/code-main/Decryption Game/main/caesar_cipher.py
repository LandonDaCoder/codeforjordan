def encypher(string, key):
    alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    key = int(key)
    string = string.lower()
    string = list(string)
    correct = False
    for i in range(len(string)):
        if string[i] in alphabet:
            alphabet = ''.join(alphabet)
            todo = alphabet.find(string[i])
            alphabet = list(alphabet)
            while not correct:
                if key > 26:
                    key = key%26
                elif key <= 26:
                    correct = True
            try:
                string[i] = alphabet[todo + key]
            except IndexError:
                string[i] = alphabet[todo - 26 + key]
    return(''.join(string))
def decypher(string, key):
    alphabet = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"]
    key = int(key)
    string = string.lower()
    string = list(string)
    correct = False
    for i in range(len(string)):
        if string[i] in alphabet:
            alphabet = ''.join(alphabet)
            todo = alphabet.find(string[i])
            alphabet = list(alphabet)
            while not correct:
                if key > 26:
                    key = key%26
                elif key <= 26:
                    correct = True
            try:
                string[i] = alphabet[todo - key]
            except IndexError:
                string[i] = alphabet[todo + 26 - key]
    return(''.join(string))