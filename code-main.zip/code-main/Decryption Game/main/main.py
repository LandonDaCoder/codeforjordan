'''
The idea is simple: A sort of game where you break into a computer with the goal of finding important information (maybe
unique randomized goals?). To do so you have to find passwords, crack encryption keys, and do a bit of detective work.

The player would first start off as a guest account (user: guest password: guest) that has no permissions and would need to
find account names and passwords until they get enough information to get the admin account and their objective.

Take notes from SDINet_Servers. I've done a lot of the work there and so I can copy that code. I also have Caeser.py
if I need some extra encryption and I could probably think up a few other forms of encryption too (or I could research them)

Optionally I could replicate a couple of commands as functions a user could enter (maybe something like cat to read files) 
to make it seem like an actual UNIX computer terminal.

Commands would be easy. Simply set up a variable (ex: "command = input("")")) where the user enters something into a blank
terminal.

For example if I wanted to create a command that would list other commands called "help" with 3 pages of commands it would 
look like:

    def help(page#):
        help1 = [
        "cat [file to read] | Use: reads a file",
        "help [page number] | Use: lists all commands"
        add in other commands to this list as needed
        ]
        help2 = [
        This is the second page of the help list.
        It would be called if needed
        ]
        help3 = [
        One last help page because 2 is too little and 4 is too many
        ]
        if page# == 1:
            return(help1)
        elif page# == 2:
            return(help2)
        elif page# == 3:
            return(help3)
    def cat(file):
        This command reads a file.
        It hasn't been coded yet but I'm sure I'll get around to it.
    command = input("").split(" ")
    if command[0] == "help":
        for i in range(1, 4):
            if int(command[1]) == i:
                print(command(i))
                y = True
    if command[0] == "copy and paste this for every command":
        y = False
        for i in range(1, 4):
            if int(command[1]) == i:
                print(command(i))
                y = True
        if not y:
            print("Unknown command!")

In summary the goal is to create a working computer terminal and system for a player to explore, find passwords, and
complete various objectives through typical hacker means.
'''

from caesar_cipher import *


class color:
    black = '\033[30m'
    red = '\033[31m'
    green = '\033[32m'
    orange = '\033[33m'
    blue = '\033[34m'
    purple = '\033[35m'
    cyan = '\033[36m'
    lightgrey = '\033[37m'
    darkgrey = '\033[90m'
    lightred = '\033[91m'
    lightgreen = '\033[92m'
    yellow = '\033[93m'
    lightblue = '\033[94m'
    pink = '\033[95m'
    lightcyan = '\033[96m'
    reset = '\033[0m'

import os
with open('Decryption Game/main/encrypted_passes.txt', 'r') as f: 
    lines = f.readlines()
    data = {} 
    for line in lines: 
        key, value = line.strip().split(',') 
        data[key] = value
login = True
count = 3
direct = True


while login:
    name = input("Enter username: ")
    password = input("Enter password: ")
    if name in data and password == decypher(data.get(name), 14):
        print("Welcome back,", name)
        login = False
    elif name in data and password != data.get(name):
        print("Incorrect password!")
    else:
        print("User not registered!")
    count = count - 1
    if count <= 0:
        print("Repeated password failures, locking system...")
        exit()

if name == "admin" and password == data.get("admin"):
    admin = True
else:
    admin = False

while True:
    choice = input("Would you like to browse files or exit? ('file' or 'exit') ")
    if choice == "file":
        "Opening files..."
        break
    elif choice == "exit":
        print("Exiting...")
        exit()
    else:
        print("Invalid choice")
        continue

while True:
    print(os.listdir("SDINet_Servers"))
    file_directory = input("What directory would you like to look at? ")
    if file_directory == "restricted" and not admin:
        print(color.red + "Warning: You do not have sufficient permissions to access this directory.")
        print(color.reset)
        continue
    print(os.listdir("SDINet_Servers/" + file_directory))
    file_name = input("What file would you like to read? (Remember to add the .txt or .py at the end of the file!): ")
    print(color.green)
    f = open("SDINet_Servers/" + file_directory + "/" + file_name, "r")
    print(f.read()) 
    print(color.reset)